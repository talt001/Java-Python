//34567890123456789012345678901234567890123456789012345678
/*File Proj05 Copyright 2013 R.G.Baldwin
*********************************************************/

import java.awt.Color;
public class Proj05{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Proj05 obj = new Proj05Runner();
    obj.run();
  }//end main
  //----------------------------------------------------//
  void run(){
    System.out.println("Hello World");
  }//end run
}//end class Proj05
//End program specifications.