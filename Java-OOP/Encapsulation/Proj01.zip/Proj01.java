//34567890123456789012345678901234567890123456789012345678
/*File Proj01 Copyright 2010 R.G.Baldwin
*********************************************************/
import java.awt.Color;

public class Proj01{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Proj01Runner obj = new Proj01Runner();
    obj.run();

    System.out.println(obj.getMars());
    System.out.println(obj.getJoe());
    System.out.println(obj.getSue());
  }//end main
}//end class Proj01
//End program specifications.
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
