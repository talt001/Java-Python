//Charles Combs for ITSE 2321 section 008 Prof. Baldwin

import java.awt.image.BufferedImage;

public class ComplicatedPicture extends Picture {

	public ComplicatedPicture() {
		// TODO Auto-generated constructor stub
	}

	public ComplicatedPicture(String fileName) {
		super(fileName);
		// TODO Auto-generated constructor stub
	}

	public ComplicatedPicture(int width, int height) {
		super(width, height);
		// TODO Auto-generated constructor stub
	}

	public ComplicatedPicture(Picture copyPicture) {
		super(copyPicture);
		// TODO Auto-generated constructor stub
	}

	public ComplicatedPicture(BufferedImage image) {
		super(image);
		// TODO Auto-generated constructor stub
	}
	
	  public String toString()
	  {
	    String output = "";
	    
	    return output;
	    
	  }

}
