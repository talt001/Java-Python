//Charles Combs for ITSE 2321 section 008 Prof. Baldwin

public class Proj08RunnerA {
	
	protected static int data;

	public Proj08RunnerA(int inData){//constructor
	    
		data = inData;
	    
	  }//end constructor

	  public int getData(){//method
		  
	    return (data / 3);
	    
	  }//end getData()

}//end class Proj08RunnerA



