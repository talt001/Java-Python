//34567890123456789012345678901234567890123456789012345678
/*File Proj03 Copyright 2010 R.G.Baldwin
*********************************************************/

public class Proj03{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Proj03Runner obj = new Proj03Runner();
    obj.run();
    System.out.println(obj.getPicture());
  }//end main
}//end class Proj03
//End program specifications.
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//34567890123456789012345678901234567890123456789012345678