//Charles Combs for ITSE 2321 section 008 Prof. Baldwin

public class Proj08RunnerB extends Proj08RunnerA{
	
	public Proj08RunnerB(){//constructor
		super(data);
		
		System.out.println("Proj08");
		System.out.println("Charles");
		System.out.println("Combs");
	   
	  }//end constructor
		
	public int getDataFromObj(Object object) {
		
		return (data / 3);
	}
	
}//end subclass

