//34567890123456789012345678901234567890123456789012345678
/*File Proj02 Copyright 2010 R.G.Baldwin
*********************************************************/

public class Proj02{
  //DO NOT MODIFY THE CODE IN THIS CLASS DEFINITION.
  public static void main(String[] args){
    Proj02Runner obj = new Proj02Runner();
    obj.run();
    System.out.println(obj.getPicture());
  }//end main
}//end class Proj02
//End program specifications.
//////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////
//34567890123456789012345678901234567890123456789012345678