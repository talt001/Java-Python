//Charles Combs for ITSE 2321 section 008 Prof. Baldwin

import java.util.*;


public class Proj11Runner {
	
public Proj11Runner(){//constructor
		
		System.out.println("Charles Combs");
			
	}//end constructor

	public Collection<String> getCollection() {//method
		
		return new TreeSet();
		
	}//end getCollection method

}
