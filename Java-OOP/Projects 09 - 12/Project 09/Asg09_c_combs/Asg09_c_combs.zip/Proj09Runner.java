//Charles Combs for ITSE 2321 section 008 Prof. Baldwin

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeSet;

public class Proj09Runner {

	public Proj09Runner(){//constructor
		
		System.out.println("Charles Combs");
			
	}//end constructor

	public Collection<String> getCollection() {//method
		
		return new ArrayList();
		
	}//end getCollection method
	
}//end class Proj09Runner
